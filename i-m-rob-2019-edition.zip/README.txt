A Pen created at CodePen.io. You can find this one at https://codepen.io/robpetrin/pen/roZmow.

 Companion pen for  a post/talk on Material Design Lite:
http://codepen.io/k3no/post/let-s-check-material-design-lite